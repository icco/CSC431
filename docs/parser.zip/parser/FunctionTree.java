import org.antlr.runtime.*;
import org.antlr.runtime.tree.*;

public class FunctionTree
   extends CommonTree
{
   public FunctionTree()
   {
      super();
   }

   public FunctionTree(CommonTree node)
   {
      super(node);
   }

   public FunctionTree(Token t)
   {
      super(t);
   }
}

